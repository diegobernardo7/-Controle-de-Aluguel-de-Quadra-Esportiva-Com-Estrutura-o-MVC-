package View;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import Controller.ControleDoSistema;
import Model.Aluguel;
import Model.Cliente;
import Model.Horario;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;


public class Main {
    public static void main(String[] args) {

        System.out.println("--- Bem-vindo ao Sistema da Quadra Society ---");

        ControleDoSistema controlador = new ControleDoSistema();

        try {
            Cliente Diego = new Cliente("Diego", 99991212);

            Horario h19 = new Horario(100, " 19:00 ás 20:00 ");
            Horario h20 = new Horario(120, " 20:00 ás 21:00 ");


            LocalDate hoje = LocalDate.now();
            List<Horario> horarioDoJoao = Arrays.asList(h19,h20);

            Aluguel aluguelJoao = controlador.registrarAluguel(Diego, hoje, horarioDoJoao);
            System.out.println("\nSucesso! Model.Aluguel registrado para: " + aluguelJoao.getCliente().getNome());
            System.out.println("Valor Total Calculado Automaticamente: R$ " + aluguelJoao.getValorTotal());

            // 4. Testando a REGRA DE OURO: Pedro tenta alugar o mesmo horário hoje!
            System.out.println("\n--- Pedro tentando alugar às 19:00... ---");
            Cliente pedro = new Cliente("Pedro Souza", 88882222);
            List<Horario> horariosDoPedro = Arrays.asList(h19); // h19 já é do João!

            controlador.registrarAluguel(pedro, hoje, horariosDoPedro);

        } catch (Exception e) {

            System.out.println("Ops! Algo deu errado: " + e.getMessage());
        }

        // Consultando o dia
        System.out.println("\n--- Resumo do Dia ---");
        List<Aluguel> doDia = controlador.consultarAlugueisPorDia(LocalDate.now());
        for (Aluguel a : doDia) {
            System.out.println("Model.Cliente: " + a.getCliente().getNome() + " | Valor: R$ " + a.getValorTotal());
        }
    }
}





