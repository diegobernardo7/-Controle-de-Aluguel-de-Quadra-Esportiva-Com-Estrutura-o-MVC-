package Model;

import java.time.LocalDate;
import java.util.List;

public class Aluguel {

    private Cliente cliente;
    private LocalDate data;
    private List<Horario> horariosEscolhidos;
    private float valorTotal;

    public Aluguel(Cliente cliente, LocalDate data, List<Horario> horariosEscolhidos) {
        this.cliente = cliente;
        this.data = data;
        this.horariosEscolhidos = horariosEscolhidos;
        this.valorTotal = calcularTotal();

    }

    private float calcularTotal() {
        float total = 0;

        for (int i = 0; i < horariosEscolhidos.size(); i++) {
            total = total + horariosEscolhidos.get(i).getValor();
        }
        return total;
    }

    public Cliente getCliente(){
        return cliente;
    }

    public LocalDate getData() {
        return data;
    }

    public List<Horario> getHorariosEscolhidos() {
        return horariosEscolhidos;
    }

    public float getValorTotal() {
        return valorTotal;
    }

}


