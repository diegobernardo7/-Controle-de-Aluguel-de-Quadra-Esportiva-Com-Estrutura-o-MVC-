package Model;

public class Cliente {

    private String nome;
    private int telefone;

    public Cliente(String nome, int telefone){
        if (nome == null || nome.trim().isEmpty()){
            throw new IllegalArgumentException("O campo 'nome' não pode estar vazio!");

        }
        this.nome = nome;
        this.telefone = telefone;

    }

    //usar o get para pegar as info. privadas!
    public String getNome() {
        return nome;
    }

    public int getTelefone() {
        return telefone;
    }
}

