package Model;

public class Horario {

    private String descricaoHora;
    private float valor;

    public Horario(float valor, String descricaoHora){
        if (valor < 0){
            throw new IllegalArgumentException("Não é possivel cadastrar horarios com valor negativo!!!");

        }

        this.descricaoHora = descricaoHora;
        this.valor = valor;

    }

    public float getValor() {
        return valor;
    }

    public String getDescricaoHora() {
        return descricaoHora;
    }


}
