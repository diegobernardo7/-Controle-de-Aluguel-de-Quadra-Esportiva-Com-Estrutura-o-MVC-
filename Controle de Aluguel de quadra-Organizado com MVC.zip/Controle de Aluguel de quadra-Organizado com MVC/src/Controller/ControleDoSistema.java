package Controller;

import Model.Aluguel;
import Model.Cliente;
import Model.Horario;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ControleDoSistema {

    private List<Aluguel> todosAlugueis = new ArrayList<>();

    public Aluguel registrarAluguel(Cliente cliente, LocalDate data, List<Horario> horariosDesejados) {

        for (int i = 0; i < todosAlugueis.size(); i++) {
            Aluguel aluguelExistente = todosAlugueis.get(i);

            if (aluguelExistente.getData().equals(data)) {

                for (int j = 0; j < horariosDesejados.size(); j++) {
                    Horario hdesejado = horariosDesejados.get(j);

                    if (aluguelExistente.getHorariosEscolhidos().contains(hdesejado)) {
                        throw new RuntimeException(
                                "ERRO!, o Model.Horario" + hdesejado.getDescricaoHora() + "já está ocupado neste dia"
                        );


                    }
                }
            }
        }


        Aluguel novoAluguel = new Aluguel(cliente, data, horariosDesejados);
        todosAlugueis.add(novoAluguel);
        return novoAluguel;


    }

    // Método para consultar os aluguéis de um dia específico
    public List<Aluguel> consultarAlugueisPorDia(LocalDate data) {
        // Criamos uma lista vazia para guardar apenas os que encontrarmos
        List<Aluguel> alugueisEncontrados = new ArrayList<>();

        for (int i = 0; i < todosAlugueis.size(); i++) {
            Aluguel aluguelAtual = todosAlugueis.get(i);

            if (aluguelAtual.getData().equals(data)) {
                // Adicionamos esse aluguel na nossa lista de resultados
                alugueisEncontrados.add(aluguelAtual);
            }
        }
        return alugueisEncontrados;
    }
}
